# Pyarmor 9.2.5 (trial), 000000, 2026-05-29T14:02:33.068745
from .pyarmor_runtime import __pyarmor__
