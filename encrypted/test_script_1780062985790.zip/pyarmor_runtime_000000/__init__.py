# Pyarmor 9.2.5 (trial), 000000, 2026-05-29T13:56:25.913290
from .pyarmor_runtime import __pyarmor__
