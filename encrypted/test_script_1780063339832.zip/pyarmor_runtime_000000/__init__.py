# Pyarmor 9.2.5 (trial), 000000, 2026-05-29T14:02:20.016138
from .pyarmor_runtime import __pyarmor__
